module stream_parity_gen (
    input  wire clk,
    input  wire reset,
    input  wire serial_in,
    output reg  parity_out
);
    reg [7:0] shift_reg;  
    function calc_even_parity;
        input [7:0] data;
        integer i;
        begin
            calc_even_parity = 1'b0;
            for (i = 0; i < 8; i = i + 1) begin
                calc_even_parity = calc_even_parity ^ data[i];
            end
        end
    endfunction

    always @(posedge clk) begin
        if (reset) begin
            shift_reg  <= 8'b0;
            parity_out <= 1'b0;
        end else begin
            shift_reg  <= {shift_reg[6:0], serial_in};
            parity_out <= calc_even_parity({shift_reg[6:0], serial_in});
        end
    end
endmodule