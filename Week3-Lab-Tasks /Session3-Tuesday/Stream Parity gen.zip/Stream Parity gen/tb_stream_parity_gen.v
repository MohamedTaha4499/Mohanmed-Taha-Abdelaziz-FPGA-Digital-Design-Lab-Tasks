`timescale 1ns / 1ps

module tb_stream_parity_gen;

    reg  clk;
    reg  reset;
    reg  serial_in;
    wire parity_out;

    stream_parity_gen uut (
        .clk(clk),
        .reset(reset),
        .serial_in(serial_in),
        .parity_out(parity_out)
    );
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        reset = 1;
        serial_in = 0;
        #15 reset = 0;
   
        @(posedge clk) serial_in = 1;
        @(posedge clk) serial_in = 0;
        @(posedge clk) serial_in = 1;
        @(posedge clk) serial_in = 1;
        @(posedge clk) serial_in = 0;
        @(posedge clk) serial_in = 0;
        @(posedge clk) serial_in = 1;
        @(posedge clk) serial_in = 0;

        #20 $finish;
    end
endmodule