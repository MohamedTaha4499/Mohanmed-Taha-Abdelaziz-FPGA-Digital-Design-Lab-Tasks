module multiplier_wrapper #(
    parameter WIDTH = 8,
    parameter MULT_STYLE = "COMBINATIONAL"
)(
    input  wire                 clk,
    input  wire                 rst,
    input  wire [WIDTH-1:0]     a,
    input  wire [WIDTH-1:0]     b,
    output wire [(2*WIDTH)-1:0] product
);
    generate
        case (MULT_STYLE)
            "COMBINATIONAL": begin : gen_comb_mult
                assign product = a * b;
            end

            "PIPELINED": begin : gen_pipe_mult
                reg [(2*WIDTH)-1:0] pipe_reg;
                always @(posedge clk or posedge rst) begin
                    if (rst)
                        pipe_reg <= {(2*WIDTH){1'b0}};
                    else
                        pipe_reg <= a * b;
                end
                assign product = pipe_reg;
            end

            "LOW_POWER": begin : gen_lp_mult
                reg [(2*WIDTH)-1:0] lp_reg;
                always @(posedge clk) begin
                    if (a || b)
                        lp_reg <= a * b;
                end
                assign product = lp_reg;
            end

            default: begin : gen_default_mult
                assign product = a * b;
            end
        endcase
    endgenerate
endmodule