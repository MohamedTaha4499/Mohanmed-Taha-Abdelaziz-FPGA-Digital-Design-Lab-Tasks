module optional_register #(
    parameter REGISTER_OUTPUT = 1
)(
    input  wire       clk,
    input  wire [7:0] data_in,
    output wire [7:0] data_out
);
    wire [7:0] logic_result;

    assign logic_result = ~data_in;

    generate
        if (REGISTER_OUTPUT == 1) begin : gen_reg_out
            reg [7:0] out_delay;
            always @(posedge clk) begin
                out_delay <= logic_result;
            end
            assign data_out = out_delay;
        end else begin : gen_comb_out
            assign data_out = logic_result;
        end
    endgenerate
endmodule