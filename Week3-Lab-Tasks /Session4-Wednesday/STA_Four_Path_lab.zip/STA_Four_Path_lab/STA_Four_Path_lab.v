module sta_four_path (
    input  wire clk,
    input  wire rst_n,
    input  wire in_1,
    input  wire in_2,
    output wire out_1,
    output wire out_2
);
    reg ff1_q;
    reg ff2_q;

    wire comb_in_to_reg;
    wire comb_reg_to_reg;
    wire comb_reg_to_out;
    wire comb_in_to_out;

    assign comb_in_to_reg  = ~in_1; 
    assign comb_reg_to_reg = ~ff1_q;
    assign comb_reg_to_out = ~ff2_q; 
    assign comb_in_to_out  = ~in_2;
    
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            ff1_q <= 1'b0;
            ff2_q <= 1'b0;
        end else begin
            ff1_q <= comb_in_to_reg;
            ff2_q <= comb_reg_to_reg;
        end
    end    
    assign out_1 = comb_reg_to_out;
    assign out_2 = comb_in_to_out;
endmodule