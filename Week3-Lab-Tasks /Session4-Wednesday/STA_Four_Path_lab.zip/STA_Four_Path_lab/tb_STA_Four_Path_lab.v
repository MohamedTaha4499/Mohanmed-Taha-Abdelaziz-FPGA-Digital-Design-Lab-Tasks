`timescale 1ns / 1ps

module tb_sta_four_path;
  
    reg clk;
    reg rst_n;
    reg in_1;
    reg in_2;
    wire out_1;
    wire out_2;
  
    sta_four_path uut (
        .clk(clk),
        .rst_n(rst_n),
        .in_1(in_1),
        .in_2(in_2),
        .out_1(out_1),
        .out_2(out_2)
    );
 
    initial begin
        clk = 0;
        forever #2 clk = ~clk; 
    end
  
    initial begin        
        rst_n = 0;
        in_1 = 0;
        in_2 = 0;

        #10;
        rst_n = 1;

        #3 in_1 = 1; in_2 = 1;
        #5 in_1 = 0; in_2 = 0;
        #10 in_1 = 1;
        
        #20;
        $finish;
    end
endmodule