module counter #(
    parameter WIDTH = 5
)(
    input clk,
    input rst,
    input load,
    input enab,
    input [WIDTH-1:0] cnt_in,
    output reg [WIDTH-1:0] cnt_out
);
    function [WIDTH-1:0] next_val;
        input load_f;
        input enab_f;
        input [WIDTH-1:0] in_f;
        input [WIDTH-1:0] current_f;
        begin
            if (load_f)
                next_val = in_f;
            else if (enab_f)
                next_val = current_f + 1;
            else
                next_val = current_f;
        end
    endfunction

    always @(posedge clk or posedge rst) begin
        if (rst)
            cnt_out <= 0;
        else
            cnt_out <= next_val(load, enab, cnt_in, cnt_out);
    end
endmodule