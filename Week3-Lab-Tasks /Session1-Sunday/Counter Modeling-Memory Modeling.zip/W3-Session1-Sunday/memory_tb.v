module memory_tb;

    parameter AWIDTH = 5;
    parameter DWIDTH = 8;

    reg clk;
    reg wr;
    reg rd;
    reg [AWIDTH-1:0] addr;
    reg [DWIDTH-1:0] data_out;
    wire [DWIDTH-1:0] data;

    assign data = wr ? data_out : {DWIDTH{1'bz}};

    memory #(AWIDTH, DWIDTH) dut (
        .clk(clk),
        .wr(wr),
        .rd(rd),
        .addr(addr),
        .data(data)
    );

    task write_mem(input [AWIDTH-1:0] t_addr, input [DWIDTH-1:0] t_data);
        begin
            @(negedge clk);
            addr = t_addr;
            data_out = t_data;
            wr = 1;
            rd = 0;
            @(negedge clk);
            wr = 0;
        end
    endtask

    task read_mem(input [AWIDTH-1:0] t_addr);
        begin
            @(negedge clk);
            addr = t_addr;
            wr = 0;
            rd = 1;
            @(negedge clk);
            rd = 0;
        end
    endtask

    always #5 clk = ~clk;

    initial begin
        clk = 0;
        wr = 0;
        rd = 0;
        addr = 0;
        data_out = 0;

        #15;
        
        write_mem(5'h0A, 8'hAA);
        write_mem(5'h1F, 8'h55);
        
        #10;
        
        read_mem(5'h0A);
        read_mem(5'h1F);
        
        #20 $finish;
    end
endmodule