module counter_tb;

    parameter WIDTH = 5;

    reg clk;
    reg rst;
    reg load;
    reg enab;
    reg [WIDTH-1:0] cnt_in;
    wire [WIDTH-1:0] cnt_out;

    counter #(WIDTH) dut (
        .clk(clk),
        .rst(rst),
        .load(load),
        .enab(enab),
        .cnt_in(cnt_in),
        .cnt_out(cnt_out)
    );
    always #5 clk = ~clk;

    initial begin
        clk = 0;
        rst = 1;
        load = 0;
        enab = 0;
        cnt_in = 0;

        #15 rst = 0;

        @(negedge clk);
        load = 1;
        cnt_in = 5'h0A;

        @(negedge clk);
        load = 0;
        enab = 1;

        #40;
        
        @(negedge clk);
        enab = 0;

        #20 $finish;
    end
endmodule