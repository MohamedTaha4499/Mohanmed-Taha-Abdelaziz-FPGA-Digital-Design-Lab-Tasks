module memory #(
    parameter AWIDTH = 5,
    parameter DWIDTH = 8
)(
    input clk,
    input wr,
    input rd,
    input [AWIDTH-1:0] addr,
    inout [DWIDTH-1:0] data
);
    reg [DWIDTH-1:0] mem_array [0:(1<<AWIDTH)-1];
    reg [DWIDTH-1:0] data_out;

    assign data = rd ? data_out : {DWIDTH{1'bz}};

    always @(posedge clk) begin
        if (wr)
            mem_array[addr] <= data;
        if (rd)
            data_out <= mem_array[addr];
    end
endmodule