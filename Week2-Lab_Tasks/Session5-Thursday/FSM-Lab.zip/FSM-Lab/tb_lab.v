`timescale 1ns / 1ps

module tb_lab_top;
    reg clk_100Hz;
    reg Reset;
    reg IN;
    
    wire [6:0] seg_6, seg_5, seg_4, seg_3, seg_2, seg_1;
   
    wire rise_tick, fall_tick, edge_tick;
    wire [3:0] rise_cnt, fall_cnt, total_cnt;

    edge_detector dut_detect (
        .clk(clk_100Hz), .Reset(Reset), .IN(IN),
        .Rise_Tick(rise_tick), .Fall_Tick(fall_tick), .Edge_Tick(edge_tick)
    );

    edge_counter dut_count (
        .clk(clk_100Hz), .Reset(Reset),
        .Rise_Tick(rise_tick), .Fall_Tick(fall_tick), .Edge_Tick(edge_tick),
        .Rise_Count(rise_cnt), .Fall_Count(fall_cnt), .Total_Count(total_cnt)
    );

    hex_decoder_top dut_disp (
        .Reset(Reset),
        .Rise_Count(rise_cnt), .Fall_Count(fall_cnt), .Total_Count(total_cnt),
        .seg_6(seg_6), .seg_5(seg_5), .seg_4(seg_4), .seg_3(seg_3), .seg_2(seg_2), .seg_1(seg_1)
    );

    initial begin
        clk_100Hz = 0;
        forever #5 clk_100Hz = ~clk_100Hz;
    end

    initial begin     
        Reset = 1;
        IN = 0;
        #20;        

        Reset = 0;
        #20;        
       
        IN = 1; 
        #20;        
       
        IN = 0; 
        #20;
        
        IN = 1; 
        #20;        
      
        Reset = 1;
        #20;
        
        $finish;
    end
endmodule