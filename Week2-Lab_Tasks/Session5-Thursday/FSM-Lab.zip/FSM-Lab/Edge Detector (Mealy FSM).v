module edge_detector (
    input wire clk,
    input wire Reset,
    input wire IN,
    output reg Rise_Tick,
    output reg Fall_Tick,
    output reg Edge_Tick
);
    reg state, next_state;

    always @(posedge clk or posedge Reset) begin
        if (Reset)
            state <= 1'b0;
        else
            state <= next_state;
    end
    
    always @(*) begin
        next_state = state;
        Rise_Tick = 1'b0;
        Fall_Tick = 1'b0;
        Edge_Tick = 1'b0;

        case (state)
            1'b0: begin
                if (IN == 1'b1) begin
                    Rise_Tick = 1'b1;
                    Edge_Tick = 1'b1;
                    next_state = 1'b1;
                end
            end
            1'b1: begin
                if (IN == 1'b0) begin
                    Fall_Tick = 1'b1;
                    Edge_Tick = 1'b1;
                    next_state = 1'b0;
                end
            end
        endcase
    end
endmodule