module edge_counter (
    input wire clk,
    input wire Reset,
    input wire Rise_Tick,
    input wire Fall_Tick,
    input wire Edge_Tick,
    output reg [3:0] Rise_Count,
    output reg [3:0] Fall_Count,
    output reg [3:0] Total_Count
);
    always @(posedge clk or posedge Reset) begin
        if (Reset) begin
            Rise_Count  <= 4'd0;
            Fall_Count  <= 4'd0;
            Total_Count <= 4'd0;
        end else begin
            if (Rise_Tick) Rise_Count <= Rise_Count + 1'b1;
            if (Fall_Tick) Fall_Count <= Fall_Count + 1'b1;
            if (Edge_Tick) Total_Count <= Total_Count + 1'b1;
        end
    end
endmodule