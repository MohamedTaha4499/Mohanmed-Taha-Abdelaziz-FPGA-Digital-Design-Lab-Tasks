module clk_div (
    input wire clk_50M,
    input wire Reset,
    output reg clk_100Hz
);
    reg [17:0] count;

    always @(posedge clk_50M or posedge Reset) begin
        if (Reset) begin
            count <= 18'd0;
            clk_100Hz <= 1'b0;
        end else if (count == 18'd249_999) begin
            count <= 18'd0;
            clk_100Hz <= ~clk_100Hz;
        end else begin
            count <= count + 1'b1;
        end
    end
endmodule