module lab_top (
    input wire clk_50M,
    input wire Reset,
    input wire IN,
    output wire [6:0] seg_6,
    output wire [6:0] seg_5,
    output wire [6:0] seg_4,
    output wire [6:0] seg_3,
    output wire [6:0] seg_2,
    output wire [6:0] seg_1
);
    wire clk_100Hz;
    wire rise_tick, fall_tick, edge_tick;
    wire [3:0] rise_cnt, fall_cnt, total_cnt;

    clk_div divider (
        .clk_50M(clk_50M),
        .Reset(Reset),
        .clk_100Hz(clk_100Hz)
    );

    edge_detector detector (
        .clk(clk_100Hz),
        .Reset(Reset),
        .IN(IN),
        .Rise_Tick(rise_tick),
        .Fall_Tick(fall_tick),
        .Edge_Tick(edge_tick)
    );

    edge_counter counter (
        .clk(clk_100Hz),
        .Reset(Reset),
        .Rise_Tick(rise_tick),
        .Fall_Tick(fall_tick),
        .Edge_Tick(edge_tick),
        .Rise_Count(rise_cnt),
        .Fall_Count(fall_cnt),
        .Total_Count(total_cnt)
    );

    hex_decoder_top display_driver (
        .Reset(Reset),
        .Rise_Count(rise_cnt),
        .Fall_Count(fall_cnt),
        .Total_Count(total_cnt),
        .seg_6(seg_6),
        .seg_5(seg_5),
        .seg_4(seg_4),
        .seg_3(seg_3),
        .seg_2(seg_2),
        .seg_1(seg_1)
    );
endmodule