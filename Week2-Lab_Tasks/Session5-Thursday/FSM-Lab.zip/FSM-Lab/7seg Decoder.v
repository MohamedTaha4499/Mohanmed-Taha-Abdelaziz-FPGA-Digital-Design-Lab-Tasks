module hex_decoder_top (
    input wire Reset,
    input wire [3:0] Rise_Count,
    input wire [3:0] Fall_Count,
    input wire [3:0] Total_Count,
    output reg [6:0] seg_6, 
    output reg [6:0] seg_5, 
    output reg [6:0] seg_4,
    output reg [6:0] seg_3, 
    output reg [6:0] seg_2, 
    output reg [6:0] seg_1 
);
    function [6:0] decode_hex;
        input [3:0] hex;
        begin
            case (hex)
                4'h0: decode_hex = 7'b1000000;
                4'h1: decode_hex = 7'b1111001;
                4'h2: decode_hex = 7'b0100100;
                4'h3: decode_hex = 7'b0110000;
                4'h4: decode_hex = 7'b0011001;
                4'h5: decode_hex = 7'b0010010;
                4'h6: decode_hex = 7'b0000010;
                4'h7: decode_hex = 7'b1111000;
                4'h8: decode_hex = 7'b0000000;
                4'h9: decode_hex = 7'b0010000;
                4'hA: decode_hex = 7'b0001000;
                4'hB: decode_hex = 7'b0000011;
                4'hC: decode_hex = 7'b1000110;
                4'hD: decode_hex = 7'b0100001;
                4'hE: decode_hex = 7'b0000110;
                4'hF: decode_hex = 7'b0001110;
                default: decode_hex = 7'b1111111;
            endcase
        end
    endfunction

    always @(*) begin
        if (Reset) begin
           
            seg_6 = 7'b1111111;
            seg_5 = 7'b1111111;
            seg_4 = 7'b0101011;
            seg_3 = 7'b1100011;
            seg_2 = 7'b1000111; 
            seg_1 = 7'b1000111;
        end else begin
            
            seg_6 = 7'b0101111;           
            seg_5 = decode_hex(Rise_Count); 
            seg_4 = 7'b0001110;          
            seg_3 = decode_hex(Fall_Count); 
            seg_2 = 7'b0001111;           
            seg_1 = decode_hex(Total_Count); 
        end
    end
endmodule