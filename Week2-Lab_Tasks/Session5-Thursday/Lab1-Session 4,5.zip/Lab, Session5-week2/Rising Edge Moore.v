module rising_edge_moore (
    input wire clk,
    input wire rst,
    input wire level,
    output reg tick
);
    localparam ZERO = 2'b00,
               EDG  = 2'b01,
               ONE  = 2'b10;
               
    reg [1:0] state, next_state;
    
    always @(posedge clk or posedge rst) begin
        if (rst)
            state <= ZERO;
        else
            state <= next_state;
    end

    always @(*) begin
        next_state = state;
        case (state)
            ZERO: begin
                if (level)
                    next_state = EDG;
                else
                    next_state = ZERO;
            end
            EDG: begin
                next_state = ONE;
            end
            ONE: begin
                if (level)
                    next_state = ONE;
                else
                    next_state = ZERO;
            end
            default: next_state = ZERO;
        endcase
    end

    always @(*) begin
        tick = (state == EDG);
    end
endmodule