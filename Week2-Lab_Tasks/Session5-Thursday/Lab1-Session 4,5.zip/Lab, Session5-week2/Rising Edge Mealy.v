module rising_edge_mealy (
    input wire clk,
    input wire rst,
    input wire level,
    output reg tick
);
    localparam ZERO = 1'b0,
               ONE  = 1'b1;
               
    reg state, next_state;
    
    always @(posedge clk or posedge rst) begin
        if (rst)
            state <= ZERO;
        else
            state <= next_state;
    end

    always @(*) begin
        next_state = state;
        tick = 1'b0;
        
        case (state)
            ZERO: begin
                if (level) begin
                    tick = 1'b1;      
                    next_state = ONE;
                end else begin
                    next_state = ZERO;
                end
            end
            
            ONE: begin
                if (level) begin
                    next_state = ONE;
                end else begin
                    next_state = ZERO;
                end
            end
            
            default: next_state = ZERO;
        endcase
    end
endmodule