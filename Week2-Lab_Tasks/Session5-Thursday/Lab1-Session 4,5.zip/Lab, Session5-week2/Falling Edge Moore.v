module falling_edge_moore (
    input wire clk,
    input wire rst,
    input wire level,
    output reg tick
);
    localparam HIGH = 2'b00,
               EDG  = 2'b01,
               LOW  = 2'b10;
               
    reg [1:0] state, next_state;

    always @(posedge clk or posedge rst) begin
        if (rst)
            state <= HIGH;
        else
            state <= next_state;
    end

    always @(*) begin
        next_state = state;
        case (state)
            HIGH: begin
                if (!level)
                    next_state = EDG;
                else
                    next_state = HIGH;
            end
            EDG: begin
                next_state = LOW;
            end
            LOW: begin
                if (!level)
                    next_state = LOW;
                else
                    next_state = HIGH;
            end
            default: next_state = HIGH;
        endcase
    end

    always @(*) begin
        tick = (state == EDG);
    end
endmodule