module falling_edge_mealy (
    input wire clk,
    input wire rst,
    input wire level,
    output reg tick
);
    localparam HIGH = 1'b1,
               LOW  = 1'b0;
               
    reg state, next_state;

    always @(posedge clk or posedge rst) begin
        if (rst)
            state <= HIGH;
        else
            state <= next_state;
    end

    always @(*) begin
        next_state = state;
        tick = 1'b0;
        
        case (state)
            HIGH: begin
                if (!level) begin
                    tick = 1'b1; 
                    next_state = LOW;
                end else begin
                    next_state = HIGH;
                end
            end
            
            LOW: begin
                if (!level) begin
                    next_state = LOW;
                end else begin
                    next_state = HIGH;
                end
            end
            
            default: next_state = HIGH;
        endcase
    end
endmodule