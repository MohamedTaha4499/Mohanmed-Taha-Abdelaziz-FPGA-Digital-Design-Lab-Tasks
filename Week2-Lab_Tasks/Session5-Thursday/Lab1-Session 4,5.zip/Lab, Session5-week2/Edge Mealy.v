module any_edge_mealy (
    input wire clk,
    input wire rst,
    input wire level,
    output reg edge_tick
);
    reg prev_level;

    always @(posedge clk or posedge rst) begin
        if (rst)
            prev_level <= 1'b0;
        else
            prev_level <= level;
    end
    
    always @(*) begin
        edge_tick = (level ^ prev_level);
    end
endmodule