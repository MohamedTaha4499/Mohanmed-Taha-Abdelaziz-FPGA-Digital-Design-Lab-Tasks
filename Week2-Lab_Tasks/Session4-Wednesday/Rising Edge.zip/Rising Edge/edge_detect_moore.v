module edge_detector_moore (
    input  wire clk,
    input  wire rst_n,
    input  wire level,
    output reg  tick
);
    localparam [1:0] ZERO = 2'b00,
                     EDG  = 2'b01,
                     ONE  = 2'b10;

    reg [1:0] current_state, next_state;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) current_state <= ZERO;
        else        current_state <= next_state;
    end

    always @(*) begin
        next_state = current_state;
        tick = 1'b0;

        case (current_state)
            ZERO: begin
                if (level) next_state = EDG;
            end
            EDG: begin
                tick = 1'b1; 
                if (level) next_state = ONE;
                else       next_state = ZERO;
            end
            ONE: begin
                if (!level) next_state = ZERO;
            end
            default: next_state = ZERO;
        endcase
    end
endmodule