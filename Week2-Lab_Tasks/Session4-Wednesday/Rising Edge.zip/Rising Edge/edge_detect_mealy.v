module edge_detector_mealy (
    input  wire clk,
    input  wire rst_n,
    input  wire level,
    output reg  tick
);
    localparam ZERO = 1'b0,
               ONE  = 1'b1;

    reg current_state, next_state;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) current_state <= ZERO;
        else        current_state <= next_state;
    end

    always @(*) begin
        next_state = current_state;
        tick = 1'b0;

        case (current_state)
            ZERO: begin
                if (level) begin
                    next_state = ONE;
                    tick = 1'b1; 
                end
            end
            ONE: begin
                if (!level) next_state = ZERO;
            end
            default: next_state = ZERO;
        endcase
    end
endmodule