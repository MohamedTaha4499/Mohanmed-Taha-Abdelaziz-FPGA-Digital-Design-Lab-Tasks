`timescale 1ns/1ps

module tb_edge_detectors;
    reg clk, rst_n, level;
    wire tick_moore, tick_mealy;

    edge_detector_moore uut_moore (.clk(clk), .rst_n(rst_n), .level(level), .tick(tick_moore));
    edge_detector_mealy uut_mealy (.clk(clk), .rst_n(rst_n), .level(level), .tick(tick_mealy));

    initial begin clk = 0; forever #5 clk = ~clk; end

    initial begin
        rst_n = 0; level = 0;
        #15 rst_n = 1;
        #12 level = 1; 
        #30 level = 0;
        #20 $finish;
    end
endmodule