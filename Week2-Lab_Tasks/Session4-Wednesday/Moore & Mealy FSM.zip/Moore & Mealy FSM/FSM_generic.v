module fsm_generic (
    input  wire clk,
    input  wire rst_n,
    input  wire a,
    input  wire b,
    output reg  y1,
    output reg  y0
);
    localparam [1:0] S0 = 2'b00,
                     S1 = 2'b01,
                     S2 = 2'b10;

    reg [1:0] current_state, next_state;
   
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) current_state <= S0;
        else        current_state <= next_state;
    end

    always @(*) begin
        next_state = current_state; 
        y0 = 1'b0;                  

        case (current_state)
            S0: begin
                if (!a) begin
                    next_state = S0;
                end else if (a && !b) begin
                    next_state = S1;
                end else if (a && b) begin
                    next_state = S2;
                    y0 = 1'b1; 
                end
            end
            S1: begin
                if (a) next_state = S0;
                else   next_state = S1;
            end
            S2: begin
                next_state = S0;
            end
            default: next_state = S0;
        endcase
    end
    
    always @(*) begin
        y1 = 1'b0;
        if (current_state == S0 || current_state == S1) begin
            y1 = 1'b1;
        end
    end
endmodule