`timescale 1ns/1ps

module tb_fsm_generic;
    reg clk, rst_n, a, b;
    wire y1, y0;

    fsm_generic uut (.clk(clk), .rst_n(rst_n), .a(a), .b(b), .y1(y1), .y0(y0));

    initial begin clk = 0; forever #5 clk = ~clk; end

    initial begin
        rst_n = 0; a = 0; b = 0;
        #15 rst_n = 1;

        @(posedge clk) a = 0;
        @(posedge clk) begin a = 1; b = 0; 
    end
        @(posedge clk) a = 0;
        @(posedge clk) a = 1;
        @(posedge clk) begin a = 1; b = 1; 
    end 
        @(posedge clk) begin a = 0; b = 0; 
    end

        #20 $finish;
    end
endmodule